PYSPARK_DRIVER_PYTHON=/usr/bin/python3  /usr/local/bin/spark-submit --master local[3]  --deploy-mode client parse_logs.py --dateoflogs 20030303

